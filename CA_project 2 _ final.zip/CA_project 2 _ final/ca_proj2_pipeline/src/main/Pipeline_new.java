package main;
/**
 * 
 */

import java.nio.file.Files;
import java.nio.file.Paths;

public class Pipeline_new {

	private static long clockcycle = 0, fetch_clock = 0, decode_clock = 0,
			ex_clock, mem_clock = 0, eb_cock = 0, prevClockCycle = 0;
	
	private static long branch_state = 0, stall_time = 0;

	private static int[][] scoreboard = new int[32][5];

	public static void decode(String i1) {
		// get the 234 bits of temp

		if (clockcycle >= fetch_clock) {
			clockcycle++;
			String bits2to4 = i1.substring(27, 30);
			System.out.println(bits2to4);
			// get 5,6 bit of temp
			String bits56 = i1.substring(25, 27);
			System.out.println(bits56);
			if (bits2to4.equals("000")) {
				if (bits56.equals("00")) {
					// load inst
					System.out.println("this is load inst");
					String rd = i1.substring(20, 25);
					String rs1 = i1.substring(12, 17);
					String imm = i1.substring(0, 12);

				}

				else if (bits56.equals("01")) {
					// store inst
					System.out.println("this is store inst");
					String rs1 = i1.substring(12, 17);
					String rs2 = i1.substring(7, 12);
					String imm = i1.substring(0, 7);
				}

				else if (bits56.equals("11")) {
					// branch inst
					System.out.println("this is branch inst");
					String rs1 = i1.substring(12, 17);
					String rs2 = i1.substring(7, 12);

				}

			}

			else if (bits2to4.equals("001") && bits56.equals("11")) {
				// jalr
				System.out.println("this is jalr inst");
				String rd = i1.substring(20, 25);
				String rs1 = i1.substring(12, 17);
			}

			else if (bits2to4.equals("010") && bits56.equals("11")) {
				// j
				System.out.println("this is jump inst");
			}

			else if (bits2to4.equals("011") && bits56.equals("11")) {
				// jal
				System.out.println("this is jal inst");
				String rd = i1.substring(20, 25);
				// save pc+4 in this rd register
			}

			else if (bits2to4.equals("100")) {
				if (bits56.equals("00")) {
					// op-imm
					System.out.println("this is op-imm inst");
					System.out.println(i1);
					String rd = i1.substring(20, 25);// see if you need to
														
					String rs1 = i1.substring(12, 17);
					String imm = i1.substring(0, 12);

				}

				else if (bits56.equals("01")) {
					// op
					System.out.println("this is op inst");
					String rd = i1.substring(20, 25);// see if you need to
														
					String rs1 = i1.substring(12, 17);
					String rs2 = i1.substring(7, 12);
					System.out.println("reg destination is:" + rd);
				}

				else if (bits56.equals("11")) {
					// system==branch
					System.out.println("this is system inst");
					String rd = i1.substring(20, 25);
					String rs1 = i1.substring(12, 17);

				}

			}

			else if (bits2to4.equals("101")) {
				if (bits56.equals("00")) {
					// aui-pc
					System.out.println("this is aui-pc inst");

				}

				else if (bits56.equals("01")) {
					// lui
					System.out.println("this is lui inst");
				}

				else if (bits56.equals("11")) {
					// system
					System.out.println("this is system inst");

				}

			} else {

				// nop inst
				System.out.println("this is nop inst");
			}
		}
	}

	public static String fetch(String instruction_data, String pc_value,
			String prev_pc_value, int i, long clockcycle) {
		// fetch stage..
		String i1 = Long.toBinaryString(Long.parseLong(instruction_data, 16));
		long pc = Long.parseLong(pc_value, 16);

		long pc_prev = 0;
		if (i > 1) {
			pc_prev = (Long.parseLong(prev_pc_value, 16));

		}

		// convert it into 32 bit format and append zeros in the front
		i1 = String.format("%32s", i1).replace(' ', '0');

		if (clockcycle % 128 == 55) {
			// inst cache miss
			clockcycle += 15;
		} else {
			clockcycle++;
		}
		
		prevClockCycle = clockcycle;
		
		if (pc - pc_prev > 4) {
			// the current inst is a branch, so stall 1 cycle
		    fetch_clock = Math.max(Math.max(fetch_clock+1, decode_clock),
					branch_state+1);
		}
		else {	
		    fetch_clock=Math.max(fetch_clock +1,decode_clock);
		
		}
		
		
		
		return i1;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// read input files

		// init all scoreboard values to 0
		for (int i = 0; i < 32; i++) {
			scoreboard[i][0] = i;
			for (int j = 1; j < 5; j++) {
				scoreboard[i][j] = 0;
			}
		}

		try {
			String pc_values = new String(
					Files.readAllBytes(Paths
							.get("X:\\\\GROWTH\\\\eclipse workspace\\\\ca_proj2_pipeline\\\\src\\\\main\\\\inst_addr_riscv_trace_project_2.txt")));
			String instruction_datas = new String(
					Files.readAllBytes(Paths
							.get("X:\\\\GROWTH\\\\eclipse workspace\\\\ca_proj2_pipeline\\\\src\\\\main\\\\inst_data_riscv_trace_project_2.txt")));

			String[] instruction_data = instruction_datas.split("\\s+");
			String[] pc_value = pc_values.split("\\s+");

			

			/*
			 * Instruction can only be accepted if the current clock cycle is greater or equal to the time stamp 
			 * of the instructions from the first pipeline stage and the last decoded instruction
			 */
//			while (clockcycle >= prevClockCycle && i < 5) {

			
			  for (int i = 0; i < 10; i++)
			    {
				
				// fetch stage
				String instruction = null;
				if (i - 1 >= 0) {
					instruction = fetch(instruction_data[i], pc_value[i],
							pc_value[i - 1], i, clockcycle);
				} else {
					instruction = fetch(instruction_data[i], pc_value[i], "0",
							i, clockcycle);
				}

				// decode stage..
				i++; //based on the scoreboard value we go to the appropriate inst
				System.out.println("About to fetch: "+i);
				String instruction_1 = null;
				if (i - 1 >= 0) {
					instruction_1 = fetch(instruction_data[i], pc_value[i],
							pc_value[i - 1], i, clockcycle);
				} else {
					instruction_1 = fetch(instruction_data[i], pc_value[i],
							"0", i, clockcycle);
				}
				System.out.println("About to decode");
				decode(instruction);

				// execute stage
				
//			}
			    }

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

/*
 * String pc_values = new String(Files.readAllBytes(Paths.get(
 * "/Users/akashmalla/Documents/COEN210_Computer_Architecture/project2/inst_data_riscv_trace_project_2.txt"
 * ))); String instruction_datas = new String(Files.readAllBytes(Paths.get(
 * "/Users/akashmalla/Documents/COEN210_Computer_Architecture/project2/inst_addr_riscv_trace_project_2.txt"
 * )));
 */